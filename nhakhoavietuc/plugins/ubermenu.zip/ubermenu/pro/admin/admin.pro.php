<?php 

require_once( 'settings.pro.php' );
require_once( 'custom.menu-item-types.pro.php' );
require_once( 'settings.menu-item.pro.php' );
require_once( 'settings.instance-manager.php' );

//require_once( 'item.settings.pro.php' );